
export enum ModelType {
  // Google
  GEMINI_FLASH = 'gemini-3-flash-preview',
  GEMINI_PRO = 'gemini-3-pro-preview',
  // OpenAI
  GPT_4O = 'gpt-4o',
  GPT_4O_MINI = 'gpt-4o-mini',
  GPT_O1 = 'o1-preview',
  GPT_O3_MINI = 'o3-mini',
  GPT_5_LITE = 'gpt-5-mini-preview', // Placeholder
}

export const ModelCategories = {
  "Google": [ModelType.GEMINI_FLASH, ModelType.GEMINI_PRO],
  "OpenAI": [ModelType.GPT_4O, ModelType.GPT_4O_MINI, ModelType.GPT_O3_MINI],
  "Premium": [ModelType.GPT_O1, ModelType.GPT_4O]
};

export interface Attachment {
  id: string;
  type: 'image' | 'video' | 'audio';
  mimeType: string;
  data: string; // base64
  url: string; // blob url for UI
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  attachments?: Attachment[];
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  model: ModelType;
  messages: Message[];
  createdAt: number;
}
