
import { ModelType, Message, Attachment } from './types';
import { sendMessageToGemini, generateImageFromText } from './geminiService';
import { sendMessageToOpenAI } from './openaiService';

const getCurrentDateTimeContext = (): string => {
  const now = new Date();
  const days = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
  const months = [
    'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
    'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
  ];
  
  const dayName = days[now.getDay()];
  const day = now.getDate();
  const monthName = months[now.getMonth()];
  const year = now.getFullYear();
  const time = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return `Системная информация: Сегодня ${dayName}, ${day} ${monthName} ${year} года. Текущее время: ${time}.`;
};

/**
 * Проверяет, является ли запрос просьбой сгенерировать изображение.
 */
const isImageGenerationRequest = (text: string): boolean => {
  const lowerText = text.toLowerCase();
  const keywords = [
    'нарисуй', 'сгенерируй картинку', 'создай изображение', 
    'draw', 'generate image', 'изобрази', 
    'картинка', 'фотография', 'сделай фото', 'visualize',
    'image of', 'photo of'
  ];
  return keywords.some(kw => lowerText.includes(kw));
};

export const routeMessage = async (
  model: ModelType,
  history: Message[],
  text: string,
  attachments: Attachment[]
): Promise<{ text: string; image?: string }> => {
  const timeContext = getCurrentDateTimeContext();

  // ПРИНУДИТЕЛЬНЫЙ ПЕРЕХВАТ ПЕРЕД ВЫЗОВОМ МОДЕЛИ
  // Если в тексте есть просьба нарисовать, мы СРАЗУ идем в генератор изображений
  if (isImageGenerationRequest(text)) {
    try {
      // Очищаем промпт от триггерных слов для лучшего качества генерации
      const cleanPrompt = text
        .replace(/(нарисуй|сгенерируй|создай|сделай|изобрази|фотография|картинка|image of|draw|generate|visualize|photo of)/gi, '')
        .trim();
      
      const imageUrl = await generateImageFromText(cleanPrompt || text);
      
      // Возвращаем результат немедленно, не беспокоя основную чат-модель
      return { text: "", image: imageUrl };
    } catch (err) {
      console.error("Direct image generation failed, falling back to chat model", err);
    }
  }

  // Если это не запрос на картинку, формируем контекст для чата
  const systemInstruction = `
    Ты - MultiChatWinter AI. 
    ${timeContext}
    ВАЖНО: Если пользователь просит что-то нарисовать или создать изображение, отвечай ТОЛЬКО фразой [DRAW_ACTION: prompt], где prompt - описание картинки на английском. 
    НИКОГДА не выводи JSON типа {"action": "dalle"}.
  `;

  const historyWithContext = [
    { 
      id: 'system-instruction', 
      role: 'model' as const, 
      text: systemInstruction, 
      timestamp: Date.now() 
    },
    ...history
  ];

  const isGemini = model.includes('gemini');
  let responseText = "";

  if (isGemini) {
    const geminiAttachments = attachments.map(a => ({
      data: a.data,
      mimeType: a.mimeType
    }));
    responseText = await sendMessageToGemini(model, historyWithContext, text, geminiAttachments);
  } else {
    responseText = await sendMessageToOpenAI(model, historyWithContext, text, attachments);
  }

  // ВТОРИЧНАЯ ПРОВЕРКА: Если модель все равно выдала JSON или наш спец-тег
  const jsonPattern = /"prompt":\s*"([^"]+)"/;
  const drawActionPattern = /\[DRAW_ACTION:\s*([^\]]+)\]/;
  
  const match = responseText.match(jsonPattern) || responseText.match(drawActionPattern);
  
  if (match || responseText.includes('"action": "dalle"')) {
    try {
      const extractedPrompt = match ? match[1] : text;
      const imageUrl = await generateImageFromText(extractedPrompt);
      return { text: "", image: imageUrl };
    } catch (e) {
      return { text: responseText };
    }
  }

  return { text: responseText };
};
