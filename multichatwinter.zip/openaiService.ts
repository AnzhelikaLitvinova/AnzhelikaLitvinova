
import { Message, ModelType, Attachment } from './types';

// USER: Insert your OpenAI API Key here
const OPENAI_API_KEY = "YOUR_OPENAI_API_KEY_HERE";

export const sendMessageToOpenAI = async (
  model: string,
  history: Message[],
  currentText: string,
  attachments: Attachment[] = []
): Promise<string> => {
  const messages: any[] = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'assistant',
    content: msg.text
  }));

  const userContent: any[] = [{ type: "text", text: currentText }];

  // Process attachments for OpenAI
  for (const att of attachments) {
    if (att.type === 'image') {
      userContent.push({
        type: "image_url",
        image_url: { url: att.data } // att.data is base64 with data: prefix
      });
    } else if (att.type === 'audio') {
      // Logic for audio: Transcription fallback
      // Since OpenAI standard chat completions don't take raw audio bytes in most models yet
      // we append a note. In a production app, we would hit /v1/audio/transcriptions here first.
      userContent[0].text += "\n[User sent an audio message]";
    } else if (att.type === 'video') {
      userContent[0].text += "\n[User sent a video message]";
    }
  }

  messages.push({ role: "user", content: userContent });

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: model,
        messages: messages,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || "OpenAI API Error");
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (err) {
    console.error("OpenAI Service Error:", err);
    throw err;
  }
};
