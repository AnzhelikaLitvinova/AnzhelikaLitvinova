
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message, ModelType } from './types';

// Use direct initialization as per guidelines
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const sendMessageToGemini = async (
  modelName: ModelType,
  history: Message[],
  currentMessage: string,
  attachments: { data: string; mimeType: string }[] = []
): Promise<string> => {
  const ai = getAI();

  const contents = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.text }]
  }));

  const parts: any[] = [{ text: currentMessage }];
  
  attachments.forEach(att => {
    parts.push({
      inlineData: {
        data: att.data.split(',')[1] || att.data,
        mimeType: att.mimeType
      }
    });
  });

  contents.push({
    role: 'user',
    parts: parts
  });

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: modelName,
      contents: contents,
      config: {
        temperature: 0.7,
        topP: 0.95,
        topK: 40,
      }
    });

    // Use response.text property (not a method)
    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

/**
 * Генерирует изображение на основе промпта.
 * Использует модель gemini-2.5-flash-image.
 */
export const generateImageFromText = async (prompt: string): Promise<string> => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    // Traverse all parts to find inlineData as per guidelines
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
      }
    }
    
    throw new Error("Model did not return an image part.");
  } catch (error) {
    console.error("Image Generation Error:", error);
    throw error;
  }
};
