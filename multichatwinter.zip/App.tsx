
import React, { useState, useEffect, useRef } from 'react';
import { ModelType, ChatSession, Message, Attachment, ModelCategories } from './types';
import { routeMessage } from './chatManager';

const App: React.FC = () => {
  const [chats, setChats] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('multi_chat_winter_data');
    return saved ? JSON.parse(saved) : [];
  });
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [showModelSelector, setShowModelSelector] = useState(false);
  
  const chatEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const activeChat = chats.find(c => c.id === activeChatId);

  useEffect(() => {
    localStorage.setItem('multi_chat_winter_data', JSON.stringify(chats));
  }, [chats]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeChat?.messages, isProcessing]);

  const createNewChat = () => {
    const newChat: ChatSession = {
      id: Date.now().toString(),
      title: `Chat ${chats.length + 1}`,
      model: ModelType.GEMINI_FLASH,
      messages: [],
      createdAt: Date.now(),
    };
    setChats([newChat, ...chats]);
    setActiveChatId(newChat.id);
  };

  const deleteChat = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const updated = chats.filter(c => c.id !== id);
    setChats(updated);
    if (activeChatId === id) setActiveChatId(updated[0]?.id || null);
  };

  const updateChatModel = (model: ModelType) => {
    if (!activeChatId) return;
    setChats(chats.map(c => c.id === activeChatId ? { ...c, model } : c));
    setShowModelSelector(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    for (const file of Array.from(files)) {
      const reader = new FileReader();
      const fileType = file.type;
      reader.onload = (event: ProgressEvent<FileReader>) => {
        // Fix: Cast event.target as FileReader to access result string safely
        const target = event.target as FileReader;
        const data = target.result as string;
        const type = fileType.startsWith('image') ? 'image' : fileType.startsWith('video') ? 'video' : 'audio';
        const newAttachment: Attachment = {
          id: Math.random().toString(36).substr(2, 9),
          type: type as 'image' | 'video' | 'audio',
          mimeType: fileType,
          data: data,
          url: URL.createObjectURL(file)
        };
        setAttachments(prev => [...prev, newAttachment]);
      };
      reader.readAsDataURL(file);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e: BlobEvent) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onload = (event: ProgressEvent<FileReader>) => {
          // Fix: Cast event.target as FileReader to access result string safely
          const target = event.target as FileReader;
          const data = target.result as string;
          const newAttachment: Attachment = {
            id: 'voice-' + Date.now(),
            type: 'audio',
            mimeType: 'audio/webm',
            data: data,
            url: URL.createObjectURL(audioBlob)
          };
          setAttachments(prev => [...prev, newAttachment]);
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone access denied", err);
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  const handleSendMessage = async () => {
    if ((!inputText.trim() && attachments.length === 0) || !activeChatId || isProcessing) return;

    const currentChat = chats.find(c => c.id === activeChatId)!;
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: inputText || (attachments.some(a => a.type === 'audio') ? "[Voice Message]" : "[Multimodal Message]"),
      attachments: [...attachments],
      timestamp: Date.now(),
    };

    setChats(prev => prev.map(c => c.id === activeChatId ? { ...c, messages: [...c.messages, userMessage] } : c));
    const sentAttachments = [...attachments];
    const sentText = inputText;
    setInputText('');
    setAttachments([]);
    setIsProcessing(true);

    try {
      const result = await routeMessage(currentChat.model, currentChat.messages, sentText || userMessage.text, sentAttachments);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: result.text,
        attachments: result.image ? [{
          id: 'gen-' + Date.now(),
          type: 'image',
          mimeType: 'image/png',
          data: result.image,
          url: result.image
        }] : [],
        timestamp: Date.now(),
      };

      setChats(prev => prev.map(c => c.id === activeChatId ? { ...c, messages: [...c.messages, aiMessage] } : c));
    } catch (error: any) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: `Error: ${error.message || "Failed to process request"}`,
        timestamp: Date.now(),
      };
      setChats(prev => prev.map(c => c.id === activeChatId ? { ...c, messages: [...c.messages, errorMsg] } : c));
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className="w-72 bg-slate-900 text-white flex flex-col shrink-0 border-r border-slate-800">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
            MultiChatWinter
          </h1>
          <button 
            onClick={createNewChat}
            className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors text-blue-400"
          >
            <i className="fas fa-plus"></i>
          </button>
        </div>
        
        <nav className="flex-1 overflow-y-auto p-2 space-y-1">
          {chats.map(chat => (
            <div
              key={chat.id}
              onClick={() => setActiveChatId(chat.id)}
              className={`group relative flex items-center p-3 rounded-xl cursor-pointer transition-all ${
                activeChatId === chat.id ? 'bg-slate-800 ring-1 ring-slate-700' : 'hover:bg-slate-800/50'
              }`}
            >
              <div className={`w-2 h-2 rounded-full mr-3 ${activeChatId === chat.id ? 'bg-blue-400 shadow-[0_0_8px_#60a5fa]' : 'bg-slate-700'}`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{chat.title}</p>
                <p className="text-[10px] text-slate-500 uppercase">{chat.model.split('-')[0]}</p>
              </div>
              <button
                onClick={(e) => deleteChat(e, chat.id)}
                className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-opacity"
              >
                <i className="fas fa-trash-alt text-xs"></i>
              </button>
            </div>
          ))}
        </nav>
      </aside>

      {/* Main Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-white shadow-2xl">
        {!activeChat ? (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50">
            <i className="fas fa-snowflake text-6xl mb-4 text-slate-200"></i>
            <p className="text-lg">Select a chat to begin</p>
          </div>
        ) : (
          <>
            <header className="h-16 border-b flex items-center justify-between px-6 bg-white shrink-0 z-10 relative">
              <div className="flex flex-col">
                <span className="text-sm font-semibold text-slate-900">{activeChat.title}</span>
                <span className="text-[10px] text-slate-500 uppercase tracking-tighter">{activeChat.model}</span>
              </div>
              
              <div className="relative">
                <button 
                  onClick={() => setShowModelSelector(!showModelSelector)}
                  className="flex items-center space-x-2 px-3 py-1.5 border rounded-lg text-xs font-medium bg-slate-50 hover:bg-slate-100 transition-all"
                >
                  <i className="fas fa-robot text-blue-500"></i>
                  <span>Switch Model</span>
                  <i className={`fas fa-chevron-${showModelSelector ? 'up' : 'down'} opacity-50`}></i>
                </button>

                {showModelSelector && (
                  <div className="absolute right-0 top-full mt-2 w-64 bg-white border rounded-xl shadow-xl p-2 space-y-3 z-50">
                    {Object.entries(ModelCategories).map(([category, models]) => (
                      <div key={category} className="space-y-1">
                        <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 rounded">
                          {category}
                        </div>
                        {models.map(m => (
                          <button
                            key={m}
                            onClick={() => updateChatModel(m as ModelType)}
                            className={`w-full text-left px-3 py-2 text-xs rounded-lg transition-colors ${
                              activeChat.model === m ? 'bg-blue-50 text-blue-600 font-bold' : 'hover:bg-slate-100 text-slate-600'
                            }`}
                          >
                            {m.replace('gemini-3-', '').replace('gpt-', '').toUpperCase()}
                          </button>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </header>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {activeChat.messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded-2xl px-4 py-3 shadow-sm ${
                    msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-800'
                  }`}>
                    {msg.attachments?.map(att => (
                      <div key={att.id} className="mb-2 rounded-lg overflow-hidden border border-white/20">
                        {att.type === 'image' && <img src={att.url} className="w-full h-auto max-h-96 object-contain" alt="attachment" />}
                        {att.type === 'video' && <video src={att.url} controls className="w-full" />}
                        {att.type === 'audio' && <audio src={att.url} controls className="w-full h-8" />}
                      </div>
                    ))}
                    {msg.text && <div className="whitespace-pre-wrap text-sm leading-relaxed">{msg.text}</div>}
                    <div className="text-[9px] mt-1 opacity-50 text-right">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              ))}
              {isProcessing && (
                <div className="flex justify-start">
                  <div className="bg-slate-100 rounded-full px-4 py-2 flex items-center space-x-1 shadow-sm">
                    <div className="w-1 h-1 bg-slate-400 rounded-full animate-bounce" />
                    <div className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-1 h-1 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div className="p-4 border-t bg-slate-50/50">
              {attachments.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-3">
                  {attachments.map(att => (
                    <div key={att.id} className="relative w-16 h-16 group shadow-sm rounded-lg overflow-hidden border bg-white">
                      {att.type === 'image' && <img src={att.url} className="w-full h-full object-cover" alt="preview" />}
                      {att.type !== 'image' && <div className="w-full h-full flex items-center justify-center bg-slate-100"><i className={`fas fa-${att.type === 'audio' ? 'microphone' : 'video'} text-slate-400`}></i></div>}
                      <button 
                        onClick={() => setAttachments(prev => prev.filter(a => a.id !== att.id))}
                        className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] shadow-sm hover:bg-red-600"
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-end space-x-3 bg-white p-2 rounded-2xl shadow-sm border focus-within:ring-2 focus-within:ring-blue-500/10 transition-all">
                <div className="flex items-center space-x-1 pb-1">
                  <label className="p-2 text-slate-400 hover:text-blue-500 cursor-pointer transition-colors">
                    <i className="fas fa-paperclip"></i>
                    <input type="file" multiple className="hidden" onChange={handleFileUpload} accept="image/*,video/*,audio/*" />
                  </label>
                  <button 
                    onMouseDown={startRecording}
                    onMouseUp={stopRecording}
                    className={`p-2 rounded-full transition-all ${isRecording ? 'text-red-500 bg-red-50 animate-pulse scale-110 shadow-lg' : 'text-slate-400 hover:text-red-500'}`}
                  >
                    <i className="fas fa-microphone"></i>
                  </button>
                </div>

                <textarea
                  rows={1}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
                  placeholder="Ask anything or request a drawing..."
                  className="flex-1 bg-transparent border-none focus:ring-0 resize-none py-2 text-sm max-h-48"
                />
                
                <button
                  onClick={handleSendMessage}
                  disabled={isProcessing}
                  className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center hover:bg-blue-700 transition-all disabled:bg-slate-200 shadow-md shadow-blue-200"
                >
                  <i className="fas fa-paper-plane text-xs"></i>
                </button>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default App;
