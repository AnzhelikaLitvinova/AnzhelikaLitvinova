
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChatSession, Message, AIProvider, Attachment } from './types';
import { MODELS, STORAGE_KEY } from './constants';
import { processChat, transcribeAudio, estimateStats } from './services/aiService';

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editMessageContent, setEditMessageContent] = useState('');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const editInputRef = useRef<HTMLInputElement>(null);

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSessions(parsed);
        if (parsed.length > 0) setActiveSessionId(parsed[0].id);
      } catch (e) {
        console.error("Failed to parse saved sessions", e);
      }
    }
  }, []);

  // Save to localStorage whenever sessions change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [sessions, activeSessionId]);

  useEffect(() => {
    if (editingChatId && editInputRef.current) {
      editInputRef.current.focus();
    }
  }, [editingChatId]);

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const createNewChat = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: `Новый чат ${sessions.length + 1}`,
      modelId: MODELS[0].id,
      messages: [],
      createdAt: Date.now()
    };
    const updatedSessions = [newSession, ...sessions];
    setSessions(updatedSessions);
    setActiveSessionId(newSession.id);
  };

  const deleteChat = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!window.confirm("Удалить этот чат навсегда?")) return;
    
    setSessions(prev => {
      const updated = prev.filter(s => s.id !== id);
      // Logic to switch active chat if the deleted one was active
      if (activeSessionId === id) {
        setActiveSessionId(updated.length > 0 ? updated[0].id : null);
      }
      return updated;
    });
  };

  const clearChatHistory = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("Вы уверены, что хотите полностью очистить историю этого чата? Все сообщения будут удалены.")) {
      setSessions(prev => prev.map(s => s.id === id ? { ...s, messages: [] } : s));
    }
  };

  const startEditingTitle = (id: string, title: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingChatId(id);
    setEditTitle(title);
  };

  const saveTitle = () => {
    if (editingChatId && editTitle.trim()) {
      setSessions(prev => prev.map(s => s.id === editingChatId ? { ...s, title: editTitle.trim() } : s));
    }
    setEditingChatId(null);
  };

  const startEditMessage = (message: Message) => {
    setEditingMessageId(message.id);
    setEditMessageContent(message.content);
  };

  const cancelEditMessage = () => {
    setEditingMessageId(null);
    setEditMessageContent('');
  };

  const saveEditedMessage = async () => {
    if (!activeSession || !editingMessageId || isProcessing) return;

    const messageIndex = activeSession.messages.findIndex(m => m.id === editingMessageId);
    if (messageIndex === -1) return;

    const oldMessage = activeSession.messages[messageIndex];
    const userStats = estimateStats(editMessageContent, oldMessage.attachments || [], activeSession.modelId);
    const newMessage: Message = { ...oldMessage, content: editMessageContent, timestamp: Date.now(), stats: userStats };
    
    const truncatedMessages = activeSession.messages.slice(0, messageIndex);
    const updatedMessages = [...truncatedMessages, newMessage];

    setSessions(prev => prev.map(s => s.id === activeSessionId ? { ...s, messages: updatedMessages } : s));
    setEditingMessageId(null);
    setEditMessageContent('');
    
    await regenerateResponse(updatedMessages);
  };

  const regenerateResponse = async (history: Message[]) => {
    if (!activeSessionId) return;
    abortControllerRef.current = new AbortController();
    setIsProcessing(true);

    try {
      const currentSession = sessions.find(s => s.id === activeSessionId)!;
      const model = MODELS.find(m => m.id === currentSession.modelId) || MODELS[0];
      const response = await processChat(currentSession.modelId, history, model.provider);
      
      const aiMessage: Message = { 
        id: (Date.now() + 1).toString(), 
        role: 'assistant', 
        content: response.text, 
        timestamp: Date.now(), 
        generatedImageUrl: response.imageUrl,
        stats: response.stats
      };
      
      setSessions(prev => prev.map(s => s.id === activeSessionId ? { ...s, messages: [...history, aiMessage] } : s));
    } catch (error: any) {
      if (error.name !== 'AbortError') console.error(error);
    } finally {
      setIsProcessing(false);
      abortControllerRef.current = null;
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    for (const file of Array.from(files)) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setAttachments(prev => [...prev, {
          type: file.type.startsWith('video') ? 'video' : file.type.startsWith('audio') ? 'audio' : 'image',
          url: URL.createObjectURL(file),
          mimeType: file.type,
          base64
        }]);
      };
      reader.readAsDataURL(file);
    }
  };

  const sendMessage = async () => {
    if ((!inputText.trim() && attachments.length === 0) || !activeSessionId || isProcessing) return;
    
    const currentSession = activeSession!;
    const userStats = estimateStats(inputText, attachments, currentSession.modelId);
    
    const userMessage: Message = { 
      id: Date.now().toString(), 
      role: 'user', 
      content: inputText, 
      timestamp: Date.now(), 
      attachments: [...attachments],
      stats: userStats
    };
    
    const updatedMessages = [...(activeSession?.messages || []), userMessage];
    setSessions(prev => prev.map(s => s.id === activeSessionId ? { ...s, messages: updatedMessages } : s));
    
    setInputText('');
    setAttachments([]);
    setIsProcessing(true);

    try {
      const model = MODELS.find(m => m.id === currentSession.modelId) || MODELS[0];
      const response = await processChat(currentSession.modelId, updatedMessages, model.provider);
      
      const aiMessage: Message = { 
        id: (Date.now() + 1).toString(), 
        role: 'assistant', 
        content: response.text, 
        timestamp: Date.now(), 
        generatedImageUrl: response.imageUrl,
        stats: response.stats
      };
      
      setSessions(prev => prev.map(s => s.id === activeSessionId ? { ...s, messages: [...updatedMessages, aiMessage] } : s));
    } catch (error) {
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => audioChunksRef.current.push(e.data);
      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const reader = new FileReader();
        reader.onload = async () => {
          setIsProcessing(true);
          const text = await transcribeAudio(reader.result as string);
          setInputText(prev => prev + " " + text);
          setIsProcessing(false);
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    } catch (err) { alert("Microphone error"); }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const formatDateLabel = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const renderMessages = () => {
    if (!activeSession) return null;
    
    const elements: React.ReactNode[] = [];
    let lastDateLabel: string | null = null;

    activeSession.messages.forEach((m) => {
      const currentDateLabel = formatDateLabel(m.timestamp);
      
      if (currentDateLabel !== lastDateLabel) {
        elements.push(
          <div key={`date-${currentDateLabel}`} className="flex items-center justify-center my-10 px-4">
            <div className="flex-1 h-px bg-slate-800"></div>
            <div className="mx-4 px-6 py-2 rounded-full border border-slate-700 bg-slate-900/50 text-[11px] font-medium text-slate-400 uppercase tracking-widest whitespace-nowrap shadow-sm">
              -------------------------------- {currentDateLabel} --------------------------------
            </div>
            <div className="flex-1 h-px bg-slate-800"></div>
          </div>
        );
        lastDateLabel = currentDateLabel;
      }

      elements.push(
        <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} group/msg`}>
          <div className={`max-w-[85%] rounded-2xl p-4 shadow-lg relative ${m.role === 'user' ? 'bg-blue-600' : 'bg-slate-800 border border-slate-700'}`}>
            {m.role === 'user' && !isProcessing && (
              <button onClick={() => startEditMessage(m)} className="absolute -left-8 top-2 opacity-0 group-hover/msg:opacity-100 p-1 text-slate-500 hover:text-slate-300 transition" title="Редактировать сообщение">
                <i className="fas fa-edit text-xs"></i>
              </button>
            )}
            
            {m.attachments?.map((att, idx) => (
              <div key={idx} className="mb-2">
                {att.type === 'image' && <img src={att.url} className="rounded-lg max-h-64 object-cover" />}
                {att.type === 'video' && <video src={att.url} controls className="rounded-lg max-h-64" />}
                {att.type === 'audio' && <audio src={att.url} controls className="w-full" />}
              </div>
            ))}

            {editingMessageId === m.id ? (
              <div className="flex flex-col gap-2">
                <textarea value={editMessageContent} onChange={(e) => setEditMessageContent(e.target.value)} className="bg-slate-900/50 border border-white/20 rounded p-2 text-sm focus:outline-none focus:ring-1 ring-white/50 resize-none w-full" rows={3} autoFocus />
                <div className="flex justify-end gap-2">
                  <button onClick={cancelEditMessage} className="text-[10px] bg-white/10 hover:bg-white/20 px-2 py-1 rounded">Отмена</button>
                  <button onClick={saveEditedMessage} className="text-[10px] bg-white/20 hover:bg-white/30 px-2 py-1 rounded">Сохранить</button>
                </div>
              </div>
            ) : (
              <>
                <div className="text-sm whitespace-pre-wrap leading-relaxed">{m.content}</div>
                {m.generatedImageUrl && <img src={m.generatedImageUrl} className="mt-2 rounded-lg max-w-sm w-full" />}
                
                {m.stats && (
                  <div className="mt-3 pt-2 border-t border-white/10 flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-white/50 italic">
                    <span title="Токенов"><i className="fas fa-coins mr-1"></i>{m.stats.tokens}</span>
                    <span title="Стоимость токена"><i className="fas fa-tag mr-1"></i>${m.stats.costPerToken.toFixed(8)}</span>
                    <span title="Итого" className="text-white/80 font-medium border-l border-white/10 pl-4"><i className="fas fa-calculator mr-1"></i>${m.stats.totalCost.toFixed(6)}</span>
                  </div>
                )}
                <div className="mt-1 text-[9px] opacity-40 text-right">{new Date(m.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
              </>
            )}
          </div>
        </div>
      );
    });

    return elements;
  };

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-100 font-sans relative">
      <aside className="w-80 flex-shrink-0 bg-slate-900 border-r border-slate-800 flex flex-col">
        <div className="p-4 border-b border-slate-800">
          <button onClick={createNewChat} className="w-full bg-blue-600 hover:bg-blue-500 py-3 rounded-xl flex items-center justify-center gap-2 font-bold transition">
            <i className="fas fa-plus"></i> Новый чат
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {sessions.map(s => (
            <div 
              key={s.id} 
              onClick={() => setActiveSessionId(s.id)} 
              className={`group flex items-center justify-between p-3 rounded-lg cursor-pointer transition ${activeSessionId === s.id ? 'bg-slate-800 ring-1 ring-blue-500/50 shadow-md' : 'hover:bg-slate-800/50'}`}
            >
              {editingChatId === s.id ? (
                <input 
                  ref={editInputRef}
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  onBlur={saveTitle}
                  onKeyDown={(e) => e.key === 'Enter' && saveTitle()}
                  onClick={(e) => e.stopPropagation()}
                  className="bg-slate-700 text-sm py-0.5 px-2 rounded-md w-full outline-none ring-1 ring-blue-500"
                />
              ) : (
                <span className="truncate text-sm font-medium pr-2">{s.title}</span>
              )}
              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={(e) => startEditingTitle(s.id, s.title, e)} className="p-1 hover:text-blue-400 text-slate-500" title="Переименовать">
                  <i className="fas fa-pencil-alt text-[10px]"></i>
                </button>
                <button onClick={(e) => clearChatHistory(s.id, e)} className="p-1 hover:text-amber-400 text-slate-500" title="Очистить историю">
                  <i className="fas fa-broom text-[10px]"></i>
                </button>
                <button onClick={(e) => deleteChat(s.id, e)} className="p-1 hover:text-red-400 text-slate-500" title="Удалить чат">
                  <i className="fas fa-trash-can text-[10px]"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-gradient-to-b from-slate-950 to-slate-900">
        {!activeSession ? (
          <div className="flex-1 flex items-center justify-center text-slate-500 italic">Выберите чат для начала общения</div>
        ) : (
          <>
            <header className="h-16 flex items-center justify-between px-6 border-b border-slate-800 bg-slate-950/50 sticky top-0 z-10 backdrop-blur-md">
              <div className="flex items-center gap-4">
                <h2 className="font-semibold text-lg truncate max-w-[200px]">{activeSession.title}</h2>
                <select value={activeSession.modelId} onChange={(e) => setSessions(prev => prev.map(s => s.id === activeSessionId ? {...s, modelId: e.target.value} : s))} className="bg-slate-800 text-sm rounded-lg px-3 py-1.5 border-none cursor-pointer hover:bg-slate-700 transition">
                  {MODELS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </div>
              <div className="text-xs text-slate-500 text-right">
                <div>{new Date().toLocaleDateString('ru-RU')}</div>
                <div>{new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</div>
              </div>
            </header>

            <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth">
              {renderMessages()}
              {isProcessing && <div className="animate-pulse text-xs text-slate-500 italic flex items-center gap-2"><i className="fas fa-circle-notch fa-spin"></i> Думаю...</div>}
            </div>

            <footer className="p-4 border-t border-slate-800 bg-slate-950/80">
              <div className="max-w-4xl mx-auto">
                {attachments.length > 0 && (
                  <div className="flex gap-2 mb-2 p-2 bg-slate-800/50 rounded-lg overflow-x-auto">
                    {attachments.map((att, idx) => (
                      <div key={idx} className="relative w-12 h-12 flex-shrink-0">
                         {att.type === 'image' ? <img src={att.url} className="w-full h-full object-cover rounded shadow-sm" /> : <div className="w-full h-full bg-slate-700 flex items-center justify-center rounded shadow-sm"><i className={`fas ${att.type === 'video' ? 'fa-video' : 'fa-music'}`}></i></div>}
                         <button onClick={() => setAttachments(attachments.filter((_, i) => i !== idx))} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-[10px] flex items-center justify-center shadow-lg hover:bg-red-600 transition">×</button>
                      </div>
                    ))}
                  </div>
                )}
                <div className="relative flex items-end gap-2 bg-slate-800/50 p-2 rounded-2xl border border-slate-700 shadow-inner">
                  <button onClick={() => fileInputRef.current?.click()} className="p-3 text-slate-400 hover:text-blue-400 transition" title="Прикрепить"><i className="fas fa-paperclip"></i></button>
                  <input type="file" ref={fileInputRef} className="hidden" multiple onChange={handleFileUpload} />
                  <textarea rows={1} value={inputText} onChange={(e) => setInputText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), sendMessage())} placeholder="Напишите что-нибудь..." className="flex-1 bg-transparent border-none focus:ring-0 py-3 text-sm resize-none placeholder:text-slate-600" />
                  <button onMouseDown={startRecording} onMouseUp={stopRecording} className={`p-3 rounded-xl transition-all ${isRecording ? 'bg-red-500 animate-pulse text-white scale-110 shadow-lg shadow-red-500/20' : 'text-slate-400 hover:text-blue-400'}`} title="Голос"><i className="fas fa-microphone"></i></button>
                  <button onClick={sendMessage} disabled={!inputText.trim() && attachments.length === 0} className="bg-blue-600 hover:bg-blue-500 text-white p-3 rounded-xl disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-md shadow-blue-500/20"><i className="fas fa-paper-plane"></i></button>
                </div>
              </div>
            </footer>
          </>
        )}
      </main>
    </div>
  );
};

export default App;
