
import { GoogleGenAI, Type } from "@google/genai";
import { Message, AIProvider, TokenStats } from "../types";

// Ключ Gemini берется автоматически из окружения.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

/**
 * ВНИМАНИЕ: Для работы моделей OpenAI и DeepSeek требуются платные API-ключи.
 */
const OPENAI_API_KEY: string = "YOUR_OPENAI_KEY_HERE"; 
const DEEPSEEK_API_KEY: string = "YOUR_DEEPSEEK_KEY_HERE";

// Примерные цены за 1 токен (усредненно для демо) в USD
const PRICES: Record<string, number> = {
  'gemini-3-flash-preview': 0.0000001,
  'gemini-3-pro-preview': 0.00000125,
  'gpt-4o': 0.000005,
  'gpt-4o-mini': 0.00000015,
  'o1-preview': 0.000015,
  'deepseek-chat': 0.0000002,
  'deepseek-reasoner': 0.0000005,
  'gemini-2.5-flash-image': 0.03, // Фиксированная цена за генерацию изображения
};

export const estimateStats = (text: string, attachments: any[] = [], modelId: string): TokenStats => {
  const isImageGen = modelId === 'gemini-2.5-flash-image';
  
  // Приблизительная оценка: 1 токен ≈ 4 символа (латиница) или 2 символа (кириллица)
  // Вложения оцениваются как 1000 токенов за штуку (условно)
  const tokens = isImageGen ? 1 : Math.ceil((text.length * 0.8) + (attachments.length * 1000));
  const costPerToken = PRICES[modelId] || 0.0000001;
  const totalCost = isImageGen ? costPerToken : tokens * costPerToken;

  return {
    tokens,
    costPerToken,
    totalCost
  };
};

export const getSystemPrompt = () => {
  const now = new Date();
  const dateStr = now.toLocaleDateString('ru-RU', { 
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
  });
  const timeStr = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  
  return `Текущая дата и время: ${dateStr}, ${timeStr}. 
  Ты — продвинутый AI ассистент MultiChatWinter_2. 
  ВАЖНОЕ ПРАВИЛО: Если пользователь просит нарисовать или создать изображение — НЕ ПИШИ ТЕКСТ. Просто выполни задачу.`;
};

export async function processChat(
  modelId: string, 
  messages: Message[], 
  provider: AIProvider
): Promise<{ text: string; imageUrl?: string; stats: TokenStats }> {
  
  const lastMessage = messages[messages.length - 1];
  const isImageRequest = /нарисуй|генерируй|создай (картинку|изображение|рисунок|график|логотип)|draw|create image|plot|graph|сделай фото/i.test(lastMessage.content);

  if (isImageRequest || modelId === 'gemini-2.5-flash-image') {
    try {
      const prompt = lastMessage.content.replace(/нарисуй|генерируй|создай (картинку|изображение|рисунок|график|логотип)|draw|create image|plot|graph|сделай фото/i, '').trim();
      // Use generateContent for image generation as per guidelines for nano banana models
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: prompt || "beautiful landscape" }] },
        config: { imageConfig: { aspectRatio: "1:1" } }
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const stats = estimateStats("", [], 'gemini-2.5-flash-image');
            return { text: "", imageUrl: `data:image/png;base64,${part.inlineData.data}`, stats };
          }
        }
      }
    } catch (error) {
      console.error("Image generation failed", error);
    }
  }

  if (provider === AIProvider.GOOGLE) {
    // Model name selection based on guidelines
    const modelName = modelId.includes('pro') ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
    
    // Convert history to contents format
    const contents = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const response = await ai.models.generateContent({
      model: modelName,
      contents: contents,
      config: { systemInstruction: getSystemPrompt() }
    });

    // Access .text property directly, not as a method
    const textOutput = response.text || "";
    const stats = estimateStats(textOutput, [], modelName);
    return { text: textOutput, stats };
  } 
  
  if (provider === AIProvider.OPENAI || provider === AIProvider.DEEPSEEK) {
    const key: string = provider === AIProvider.OPENAI ? OPENAI_API_KEY : DEEPSEEK_API_KEY;
    const endpoint = provider === AIProvider.OPENAI 
      ? "https://api.openai.com/v1/chat/completions" 
      : "https://api.deepseek.com/chat/completions";

    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${key}`
        },
        body: JSON.stringify({
          model: modelId,
          messages: [
            { role: "system", content: getSystemPrompt() },
            ...messages.map(m => ({ role: m.role, content: m.content }))
          ]
        })
      });
      
      const data = await response.json();
      const content = data.choices[0].message.content || "";
      const usage = data.usage?.total_tokens || content.length;
      const stats = {
        tokens: usage,
        costPerToken: PRICES[modelId] || 0.000001,
        totalCost: usage * (PRICES[modelId] || 0.000001)
      };

      return { text: content, stats };
    } catch (e) {
      return { text: "Ошибка API", stats: { tokens: 0, costPerToken: 0, totalCost: 0 } };
    }
  }

  return { text: "⚠️ Ошибка", stats: { tokens: 0, costPerToken: 0, totalCost: 0 } };
}

export async function transcribeAudio(base64: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { text: "Пожалуйста, преобразуй это аудио в текстовое сообщение." },
        { inlineData: { data: base64.includes(',') ? base64.split(',')[1] : base64, mimeType: 'audio/wav' } }
      ]
    }
  });
  // Use .text property directly
  return response.text || "";
}
