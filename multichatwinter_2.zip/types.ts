
export enum AIProvider {
  GOOGLE = 'Google',
  OPENAI = 'OpenAI',
  DEEPSEEK = 'DeepSeek',
  PREMIUM = 'Premium'
}

export interface ModelInfo {
  id: string;
  name: string;
  provider: AIProvider;
  description: string;
}

export interface Attachment {
  type: 'image' | 'video' | 'audio';
  url: string;
  mimeType: string;
  base64?: string;
}

export interface TokenStats {
  tokens: number;
  costPerToken: number;
  totalCost: number;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  attachments?: Attachment[];
  generatedImageUrl?: string;
  stats?: TokenStats;
}

export interface ChatSession {
  id: string;
  title: string;
  modelId: string;
  messages: Message[];
  createdAt: number;
}
