
import { AIProvider, ModelInfo } from './types';

export const MODELS: ModelInfo[] = [
  // Google Models
  { id: 'gemini-3-flash-preview', name: 'Gemini 3 Flash', provider: AIProvider.GOOGLE, description: 'Fast and efficient for daily tasks' },
  { id: 'gemini-3-pro-preview', name: 'Gemini 3 Pro', provider: AIProvider.GOOGLE, description: 'Advanced reasoning and high-quality generation' },
  
  // OpenAI Models
  { id: 'gpt-4o', name: 'GPT-4o', provider: AIProvider.OPENAI, description: 'Omni model for text, audio, and vision' },
  { id: 'gpt-4o-mini', name: 'GPT-4o mini', provider: AIProvider.OPENAI, description: 'Optimized for speed and cost' },
  { id: 'o1-preview', name: 'OpenAI o1', provider: AIProvider.OPENAI, description: 'Next-gen reasoning model' },
  
  // DeepSeek Models
  { id: 'deepseek-chat', name: 'DeepSeek Chat', provider: AIProvider.DEEPSEEK, description: 'Advanced general purpose model' },
  { id: 'deepseek-reasoner', name: 'DeepSeek Reasoner', provider: AIProvider.DEEPSEEK, description: 'Specialized for complex reasoning' },
  
  // Premium / Specialized (Aliases)
  { id: 'gemini-2.5-flash-image', name: 'Imagen Premium', provider: AIProvider.PREMIUM, description: 'Dedicated high-fidelity image generation' }
];

export const STORAGE_KEY = 'multichatwinter_2_data';
