
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Message, Role, HistoryEntry } from './types';
import { getGeminiResponse, extractTextFromImage } from './services/geminiService';
import { APP_TITLE } from './constants.tsx';

// Icons
const SendIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>;
const MicIcon = ({ active }: { active: boolean }) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={active ? "#ef4444" : "currentColor"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>;
const CameraIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>;
const ResetIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>;
const ChartIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>;
const HistoryIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 8v4l3 3"/><circle cx="12" cy="12" r="9"/><path d="M3.05 11a9 9 0 1 1 .5 4m-.5 5v-5h5"/></svg>;
const CloseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>;

const PieChart = ({ description }: { description: string }) => {
  // Enhanced regex to capture labels that might contain letters, spaces or hyphens before a number/percent
  // Example: "Овощи и фрукты 45%, Проезд 15%..."
  const segments = description.split(',').map(s => s.trim());
  const data = segments.map(s => {
    const match = s.match(/(.+?)\s*(\d+)/);
    if (match) {
      return { label: match[1].trim(), value: parseInt(match[2]) };
    }
    return null;
  }).filter((d): d is { label: string; value: number } => d !== null);
  
  if (data.length === 0) {
    data.push({ label: 'Прочее', value: 100 });
  }

  const total = data.reduce((acc, curr) => acc + curr.value, 0);
  let cumulativePercent = 0;

  const getCoordinatesForPercent = (percent: number) => {
    const x = Math.cos(2 * Math.PI * percent);
    const y = Math.sin(2 * Math.PI * percent);
    return [x, y];
  };

  const colors = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

  return (
    <div className="flex flex-col items-center gap-6 w-full py-2">
      <div className="relative w-40 h-40">
        <svg viewBox="-1 -1 2 2" className="transform -rotate-90 w-full h-full drop-shadow-lg">
          {data.map((slice, i) => {
            const [startX, startY] = getCoordinatesForPercent(cumulativePercent);
            cumulativePercent += slice.value / total;
            const [endX, endY] = getCoordinatesForPercent(cumulativePercent);
            const largeArcFlag = slice.value / total > 0.5 ? 1 : 0;
            const pathData = [
              `M ${startX} ${startY}`,
              `A 1 1 0 ${largeArcFlag} 1 ${endX} ${endY}`,
              `L 0 0`,
            ].join(' ');

            return (
              <path 
                key={i} 
                d={pathData} 
                fill={colors[i % colors.length]} 
                stroke="#fff" 
                strokeWidth="0.01" 
                className="transition-opacity hover:opacity-80"
              />
            );
          })}
        </svg>
      </div>
      <div className="grid grid-cols-2 gap-x-6 gap-y-3 w-full px-2">
        {data.map((slice, i) => (
          <div key={i} className="flex items-start gap-2 text-[12px] font-medium text-slate-700">
            <span className="w-3 h-3 rounded-full shrink-0 mt-0.5" style={{ backgroundColor: colors[i % colors.length] }}></span>
            <span className="leading-tight">
              {slice.label} <span className="text-slate-400 font-normal">({Math.round((slice.value / total) * 100)}%)</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [historySearch, setHistorySearch] = useState('');
  const [historyData, setHistoryData] = useState<HistoryEntry[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('spending_history');
    if (saved) setHistoryData(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('spending_history', JSON.stringify(historyData));
  }, [historyData]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    const initialGreeting: Message = {
      role: Role.ASSISTANT,
      content: "Привет! Я твой AI-секретарь «Бюджет-трекер». Помогу проанализировать твои траты за сегодня. Пришли мне список покупок текстом, голосом или просто скинь фото чека!",
      timestamp: Date.now()
    };
    setMessages([initialGreeting]);
  }, []);

  const handleSend = async (text?: string) => {
    const content = text || input;
    if (!content.trim()) return;

    const userMessage: Message = { role: Role.USER, content, timestamp: Date.now() };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    const response = await getGeminiResponse(newMessages);
    
    if (response.includes("Консультация") || response.includes("Итог дня")) {
      const newEntry: HistoryEntry = {
        id: Date.now().toString(),
        date: new Date().toLocaleDateString('ru-RU'),
        total: 0,
        summary: response.substring(0, 400),
        categories: []
      };
      setHistoryData(prev => [newEntry, ...prev]);
    }

    setMessages(prev => [...prev, {
      role: Role.ASSISTANT,
      content: response,
      timestamp: Date.now()
    }]);
    setIsLoading(false);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = (reader.result as string).split(',')[1];
      const extractedText = await extractTextFromImage(base64);
      handleSend(`[Фотография чека]. Распознанные данные: ${extractedText}`);
    };
    reader.readAsDataURL(file);
  };

  const startVoice = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert("Голосовой ввод не поддерживается.");
      return;
    }
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.lang = 'ru-RU';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => handleSend(`[Голосовой ввод]: ${event.results[0][0].transcript}`);
    recognition.start();
  };

  const filteredHistory = useMemo(() => {
    return historyData.filter(h => 
      h.summary.toLowerCase().includes(historySearch.toLowerCase()) || 
      h.date.includes(historySearch)
    );
  }, [historyData, historySearch]);

  const parseMessageContent = (content: string) => {
    const lines = content.split('\n');
    let hasChartTrigger = false;
    let chartDescription = "";
    const filteredContent = lines.filter(line => {
      if (line.includes('[ГЕНЕРАЦИЯ_ИЗОБРАЖЕНИЯ:')) {
        hasChartTrigger = true;
        chartDescription = line.match(/\[ГЕНЕРАЦИЯ_ИЗОБРАЖЕНИЯ: (.*?)\]/)?.[1] || "";
        return false;
      }
      return !line.includes('[ОЗВУЧИТЬ_ОТВЕТ:');
    }).join('\n');
    return { filteredContent, hasChartTrigger, chartDescription };
  };

  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto bg-white shadow-2xl overflow-hidden relative">
      <header className="bg-white border-b border-slate-100 px-6 py-4 flex justify-between items-center shrink-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg">
            <span className="text-xl font-bold">B</span>
          </div>
          <div>
            <h1 className="font-bold text-slate-800 text-lg leading-tight">{APP_TITLE}</h1>
            <p className="text-xs text-green-500 font-medium flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> Активен
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setIsHistoryOpen(true)} className="p-2 hover:bg-slate-50 rounded-lg text-slate-400 hover:text-indigo-600 transition-colors" title="История">
            <HistoryIcon />
          </button>
          <button onClick={() => setMessages([{ role: Role.ASSISTANT, content: "Привет! Давай начнем заново.", timestamp: Date.now() }])} className="p-2 hover:bg-slate-50 rounded-lg text-slate-400 hover:text-red-600 transition-colors" title="Очистить чат">
            <ResetIcon />
          </button>
        </div>
      </header>

      {isHistoryOpen && (
        <div className="absolute inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setIsHistoryOpen(false)} />
          <div className="relative w-[85%] max-w-md bg-white h-full shadow-2xl flex flex-col animate-[slideIn_0.3s_ease-out]">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">История</h2>
              <button onClick={() => setIsHistoryOpen(false)} className="p-2 hover:bg-slate-50 rounded-full text-slate-400">
                <CloseIcon />
              </button>
            </div>
            <div className="p-4 border-b border-slate-50">
              <input 
                type="text" 
                placeholder="Поиск по расходам..." 
                className="w-full bg-slate-50 border-none rounded-xl py-2 px-4 text-sm focus:ring-2 focus:ring-indigo-500"
                value={historySearch}
                onChange={e => setHistorySearch(e.target.value)}
              />
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {filteredHistory.length > 0 ? filteredHistory.map(item => (
                <div key={item.id} className="p-4 rounded-xl border border-slate-100 hover:border-indigo-200 transition-all bg-white shadow-sm">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold text-indigo-600 px-2 py-1 bg-indigo-50 rounded-md">{item.date}</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap line-clamp-6">{item.summary}</p>
                </div>
              )) : (
                <div className="flex flex-col items-center justify-center h-40 text-slate-400">
                  <HistoryIcon />
                  <p className="mt-2 text-sm font-medium">Записей не найдено</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <main className="flex-1 overflow-y-auto p-4 space-y-6 bg-slate-50/50">
        {messages.map((msg, idx) => {
          const { filteredContent, hasChartTrigger, chartDescription } = parseMessageContent(msg.content);
          return (
            <div key={idx} className={`flex ${msg.role === Role.USER ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[90%] px-5 py-3 rounded-2xl shadow-sm text-sm leading-relaxed ${msg.role === Role.USER ? 'bg-indigo-600 text-white rounded-tr-none shadow-indigo-100' : 'bg-white border border-slate-100 text-slate-700 rounded-tl-none shadow-slate-200/50'}`}>
                <div className="whitespace-pre-wrap">{filteredContent}</div>
                {hasChartTrigger && (
                  <div className="mt-4 p-5 bg-white rounded-xl border border-indigo-100 flex flex-col items-center shadow-sm">
                    <div className="flex items-center gap-2 mb-2 w-full border-b border-slate-50 pb-2">
                      <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                        <ChartIcon />
                      </div>
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Аналитика по категориям</span>
                    </div>
                    <PieChart description={chartDescription} />
                  </div>
                )}
                <div className={`text-[10px] mt-2 font-medium opacity-60 ${msg.role === Role.USER ? 'text-indigo-100' : 'text-slate-400'}`}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          );
        })}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-100 px-5 py-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-3">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-75"></div>
              </div>
              <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Обработка...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </main>

      <footer className="p-4 bg-white border-t border-slate-100 shrink-0">
        <div className="flex gap-2 items-center">
          <button onClick={() => fileInputRef.current?.click()} className="p-3 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-100 transition-all active:scale-95">
            <CameraIcon />
          </button>
          <button onClick={startVoice} className={`p-3 rounded-xl transition-all active:scale-95 ${isListening ? 'bg-red-50 text-red-500 scale-105' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'}`}>
            <MicIcon active={isListening} />
          </button>
          <input type="file" className="hidden" ref={fileInputRef} accept="image/*" onChange={handleImageUpload} />
          <div className="flex-1 relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Введите траты..."
              className="w-full bg-slate-50 border-none rounded-xl py-3.5 pl-4 pr-12 text-sm focus:ring-2 focus:ring-indigo-500 transition-all text-slate-700 placeholder:text-slate-400"
            />
            <button onClick={() => handleSend()} disabled={!input.trim() || isLoading} className="absolute right-2 top-2 p-1.5 bg-indigo-600 text-white rounded-lg disabled:opacity-50 shadow-md active:scale-90">
              <SendIcon />
            </button>
          </div>
        </div>
      </footer>
      <style>{`
        @keyframes slideIn {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
      `}</style>
    </div>
  );
};

export default App;
