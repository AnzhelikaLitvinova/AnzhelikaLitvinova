
export enum Role {
  USER = 'user',
  ASSISTANT = 'assistant',
  SYSTEM = 'system'
}

export interface Message {
  role: Role;
  content: string;
  timestamp: number;
}

export interface SpendingData {
  item: string;
  amount: number;
}

export interface HistoryEntry {
  id: string;
  date: string;
  total: number;
  summary: string;
  categories: { name: string; amount: number }[];
}
