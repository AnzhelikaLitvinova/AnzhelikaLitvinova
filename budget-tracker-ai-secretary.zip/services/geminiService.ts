
import { GoogleGenAI } from "@google/genai";
import { Message, Role } from "../types";
import { SYSTEM_PROMPT } from "../constants.tsx";

export const getGeminiResponse = async (history: Message[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  // Transform history to Gemini format
  const contents = history.map(msg => ({
    role: msg.role === Role.ASSISTANT ? 'model' : 'user',
    parts: [{ text: msg.content }]
  }));

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.7,
      },
    });

    return response.text || "Извините, возникла ошибка при генерации ответа.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Произошла техническая ошибка. Пожалуйста, попробуйте позже.";
  }
};

export const extractTextFromImage = async (base64Image: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            { text: "Извлеки текстовый список трат с этого изображения чека или скриншота. Только список в формате 'название сумма', без лишних пояснений." },
            { inlineData: { mimeType: "image/jpeg", data: base64Image } }
          ]
        }
      ]
    });
    return response.text || "";
  } catch (error) {
    console.error("OCR Error:", error);
    return "Не удалось распознать текст на изображении.";
  }
};
