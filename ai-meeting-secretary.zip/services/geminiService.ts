
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const MODEL_NAME = 'gemini-3-pro-preview';

export const analyzeMeeting = async (
  fileData?: { data: string; mimeType: string },
  textInput?: string,
  urlInput?: string
): Promise<{ transcript: string; protocol: string }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `
    Вы — профессиональный AI-секретарь. Ваша задача — проанализировать материалы совещания и создать структурированный протокол.
    
    ПРАВИЛА ОФОРМЛЕНИЯ И ЯЗЫКА:
    1. ВСЕГДА генерируйте текст ИСКЛЮЧИТЕЛЬНО на русском языке.
    2. Используйте только стандартные русские буквы, цифры и пунктуацию.
    3. Избегайте нестандартных спецсимволов, которые могут нарушить кодировку UTF-8.
    4. Строго соблюдайте синтаксис Markdown (# для заголовков, - для списков, ** для жирного текста).
    5. В КОНЦЕ ответа ОБЯЗАТЕЛЬНО добавьте служебную пометку: [КОДИРОВКА: UTF-8]

    Если предоставлен аудио/видео файл, сначала выполните его полную транскрибацию.
    Если предоставлен текст, используйте его.

    МАТЕРИАЛЫ:
    ${textInput ? `Текст: ${textInput}` : ''}
    ${urlInput ? `Ссылка: ${urlInput}` : ''}

    ВАЖНО: Ваш ответ должен состоять из двух четких частей, разделенных маркером "---PROTOCOL_START---".
    Часть 1: Полная транскрибация (на русском языке).
    Часть 2: Протокол в формате Markdown, строго следуя этой структуре:

    # ПРОТОКОЛ СОВЕЩАНИЯ
    **Проект:** [Название проекта или "Не указан"]
    **Дата и время:** [Дата]
    **Тип встречи:** [Совещание / Планёрка / Встреча с клиентом]
    **Участники:** [Имена и роли]

    ## 1. Цель и основные темы встречи
    ### Цель встречи:
    [Описание]
    ### Основные темы:
    - Тема 1

    ## 2. Ключевые обсуждения и решения
    ### [Название темы]
    **Обсуждение:** [Суть обсуждения только на русском]
    **Принятое решение:** [Формулировка]

    ## 3. Задачи и поручения (Action Items)
    | № | Задача | Исполнитель | Срок | Приоритет | Статус |
    |---|--------|-------------|------|-----------|--------|
    | 1 | ...    | ...         | ...  | ...       | ...    |

    ## 4. Открытые вопросы
    - [Вопрос]

    ## 5. Следующая встреча
    **Дата и время:** [Дата]

    ## 6. Краткие выводы
    [Итоги]

    [КОДИРОВКА: UTF-8]
  `;

  const contents: any[] = [{ text: prompt }];
  if (fileData) {
    contents.push({
      inlineData: {
        data: fileData.data,
        mimeType: fileData.mimeType
      }
    });
  }

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: { parts: contents },
  });

  const fullText = response.text || '';
  const [transcriptPart, protocolPart] = fullText.split('---PROTOCOL_START---');

  return {
    transcript: transcriptPart?.trim() || 'Транскрипт не сформирован.',
    protocol: protocolPart?.trim() || fullText
  };
};

export const askQuestion = async (
  question: string,
  context: { transcript: string; protocol: string },
  history: { role: 'user' | 'model'; parts: { text: string }[] }[]
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const systemInstruction = `
    Вы — AI-секретарь, отвечающий на вопросы по совещанию. 
    1. ОТВЕЧАЙТЕ ИСКЛЮЧИТЕЛЬНО НА РУССКОМ ЯЗЫКЕ.
    2. Используйте кодировку UTF-8 и стандартную пунктуацию.
    3. Используйте ПРОТОКОЛ и ТРАНСКРИПТ ниже как единственный источник информации.
    4. В КОНЦЕ каждого ответа ОБЯЗАТЕЛЬНО добавляйте: [КОДИРОВКА: UTF-8]
    
    ПРОТОКОЛ:
    ${context.protocol}
    
    ТРАНСКРИПТ:
    ${context.transcript}
  `;

  const response = await ai.models.generateContent({
    model: MODEL_NAME,
    contents: [
      ...history,
      { role: 'user', parts: [{ text: question }] }
    ],
    config: {
      systemInstruction
    }
  });

  return response.text || 'Извините, не удалось получить ответ. [КОДИРОВКА: UTF-8]';
};
