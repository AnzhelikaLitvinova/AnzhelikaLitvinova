
import React, { useState, useRef, useEffect } from 'react';
import { analyzeMeeting, askQuestion } from './services/geminiService';
import { Message, MeetingContext } from './types';
import ProtocolView from './components/ProtocolView';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      text: 'Здравствуйте! Отправьте мне запись, ссылку или текст совещания — я создам структурированный протокол в PDF-формате. После этого вы сможете задавать вопросы по итогам встречи. Что бы вы хотели проанализировать?',
      timestamp: new Date()
    }
  ]);
  const [inputText, setTextInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [meetingContext, setMeetingContext] = useState<MeetingContext | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  
  // Ref to hold the current abort controller for the active request
  const abortControllerRef = useRef<AbortController | null>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsAnalyzing(false);
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: 'Генерация остановлена пользователем.', 
        timestamp: new Date() 
      }]);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    abortControllerRef.current = new AbortController();
    setMessages(prev => [...prev, { role: 'user', text: `Файл: ${file.name}`, timestamp: new Date() }]);

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Data = (reader.result as string).split(',')[1];
          const result = await analyzeMeeting({ data: base64Data, mimeType: file.type });
          
          if (abortControllerRef.current?.signal.aborted) return;

          setMeetingContext(result);
          setMessages(prev => [
            ...prev, 
            { role: 'model', text: 'Протокол успешно сформирован. Вы можете просмотреть его ниже или задать вопросы.', timestamp: new Date(), protocol: result.protocol, isProtocol: true }
          ]);
        } catch (err) {
          if (err instanceof Error && err.name === 'AbortError') return;
          setMessages(prev => [...prev, { role: 'model', text: 'Ошибка при обработке файла.', timestamp: new Date() }]);
        } finally {
          setIsAnalyzing(false);
          abortControllerRef.current = null;
        }
      };
      reader.readAsDataURL(file);
    } catch (error) {
      setIsAnalyzing(false);
      abortControllerRef.current = null;
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim() || isAnalyzing) return;

    const userMessage = inputText;
    setTextInput('');
    setIsAnalyzing(true);
    abortControllerRef.current = new AbortController();
    setMessages(prev => [...prev, { role: 'user', text: userMessage, timestamp: new Date() }]);

    try {
      if (!meetingContext) {
        const result = await analyzeMeeting(undefined, userMessage);
        if (abortControllerRef.current?.signal.aborted) return;
        
        setMeetingContext(result);
        setMessages(prev => [
          ...prev, 
          { role: 'model', text: 'Протокол успешно сформирован на основе вашего текста.', timestamp: new Date(), protocol: result.protocol, isProtocol: true }
        ]);
      } else {
        const history = messages
          .filter(m => !m.isProtocol)
          .map(m => ({ role: m.role, parts: [{ text: m.text }] }));
        const answer = await askQuestion(userMessage, meetingContext, history);
        
        if (abortControllerRef.current?.signal.aborted) return;
        setMessages(prev => [...prev, { role: 'model', text: answer, timestamp: new Date() }]);
      }
    } catch (error: any) {
      if (error?.name === 'AbortError') return;
      setMessages(prev => [...prev, { role: 'model', text: 'Произошла ошибка при выполнении запроса.', timestamp: new Date() }]);
    } finally {
      setIsAnalyzing(false);
      abortControllerRef.current = null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col max-w-6xl mx-auto px-4 py-8">
      <header className="mb-8 text-center print:hidden">
        <h1 className="text-4xl font-extrabold text-slate-900 mb-2">AI-Секретарь</h1>
        <p className="text-slate-500">Протоколирование и анализ совещаний нового поколения</p>
      </header>

      <main className="flex-1 flex flex-col gap-6">
        {/* Chat History */}
        <div className="flex-1 overflow-y-auto space-y-4 bg-white rounded-2xl p-6 shadow-sm border border-slate-200 max-h-[60vh] print:hidden">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'bg-slate-100 text-slate-800 rounded-tl-none'
              }`}>
                <p className="whitespace-pre-wrap">{msg.text}</p>
                <span className="text-[10px] opacity-70 mt-1 block">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))}
          {isAnalyzing && (
            <div className="flex justify-start">
              <div className="bg-slate-100 text-slate-800 rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-2">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                <span className="text-sm font-medium">Обработка...</span>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Action Bar */}
        <div className="bg-white rounded-2xl p-4 shadow-lg border border-slate-200 sticky bottom-8 print:hidden">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => fileInputRef.current?.click()}
              disabled={isAnalyzing}
              className="p-3 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all disabled:opacity-30"
              title="Загрузить аудио/видео"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.414a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
              </svg>
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="audio/*,video/*" 
              onChange={handleFileUpload}
            />
            
            <input 
              type="text"
              value={inputText}
              onChange={(e) => setTextInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              disabled={isAnalyzing}
              placeholder={isAnalyzing ? "Ожидайте ответа..." : (meetingContext ? "Задайте вопрос по итогам..." : "Вставьте текст, ссылку или начните анализ...")}
              className="flex-1 bg-slate-50 border-none focus:ring-2 focus:ring-blue-500 rounded-xl px-4 py-3 outline-none disabled:bg-slate-100"
            />

            {isAnalyzing ? (
              <button 
                onClick={handleStop}
                className="bg-red-500 hover:bg-red-600 text-white p-3 rounded-xl transition-all flex items-center justify-center"
                title="Остановить генерацию"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <rect x="6" y="6" width="12" height="12" rx="2" />
                </svg>
              </button>
            ) : (
              <button 
                onClick={handleSendMessage}
                disabled={!inputText.trim()}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white p-3 rounded-xl transition-all"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* Protocol View Section */}
        {meetingContext && (
          <div className="mt-8">
            <ProtocolView content={meetingContext.protocol} />
          </div>
        )}
      </main>
      
      <footer className="mt-12 text-center text-slate-400 text-sm print:hidden">
        &copy; {new Date().getFullYear()} AI Meeting Secretary. Все данные защищены.
      </footer>
    </div>
  );
};

export default App;
