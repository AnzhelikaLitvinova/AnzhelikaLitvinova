
import React, { useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface ProtocolViewProps {
  content: string;
}

const ProtocolView: React.FC<ProtocolViewProps> = ({ content }) => {
  const protocolRef = useRef<HTMLDivElement>(null);

  const handleDownloadMd = () => {
    let finalContent = content.trim();
    if (!finalContent.includes('[КОДИРОВКА: UTF-8]')) {
      finalContent += '\n\n[КОДИРОВКА: UTF-8]';
    }
      
    const blob = new Blob([finalContent], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    
    const date = new Date().toLocaleDateString('ru-RU').replace(/\./g, '-');
    link.download = `Протокол_совещания_${date}.md`;
    
    document.body.appendChild(link);
    link.click();
    
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportPDF = () => {
    if (!protocolRef.current) return;

    // Создаем клон элемента для экспорта, чтобы применить специфические стили для PDF
    const element = protocolRef.current.cloneNode(true) as HTMLElement;
    element.style.padding = "20px";
    element.style.color = "#000";

    const date = new Date().toLocaleDateString('ru-RU').replace(/\./g, '-');
    const filename = `Протокол_совещания_${date}.pdf`;

    // Настройки для html2pdf
    const opt = {
      margin:       [10, 10, 10, 10],
      filename:     filename,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { 
        scale: 2, 
        useCORS: true, 
        letterRendering: true,
        logging: false 
      },
      jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    // Вызов библиотеки из глобального окна (скрипт в index.html)
    // @ts-ignore
    window.html2pdf()
      .set(opt)
      .from(element)
      .save()
      .then(() => {
        console.log('PDF успешно сохранен в папку Загрузки');
      });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-8 max-w-4xl mx-auto my-8 print:shadow-none print:border-none print:p-0 print:my-0">
      <div className="flex justify-between items-center mb-6 print:hidden">
        <h2 className="text-xl font-bold text-slate-800">Протокол совещания</h2>
        <div className="flex gap-2">
          <button 
            onClick={handleDownloadMd}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-lg transition-colors flex items-center gap-2 border border-slate-300"
            title="Скачать в формате Markdown (UTF-8)"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Скачать .md
          </button>
          <button 
            onClick={handleExportPDF}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2 shadow-md hover:shadow-lg active:transform active:scale-95"
            title="Экспортировать протокол в PDF и сохранить на ПК"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
            Сохранить PDF
          </button>
        </div>
      </div>
      
      {/* Скрытый или видимый контейнер для рендеринга PDF */}
      <div ref={protocolRef} id="protocol-content" className="markdown-content bg-white">
        <ReactMarkdown remarkPlugins={[remarkGfm]}>
          {content}
        </ReactMarkdown>
      </div>

      <style>{`
        .markdown-content { color: #1e293b; font-size: 1rem; }
        .markdown-content h1 { color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; margin-top: 0; margin-bottom: 16px; font-size: 24pt; }
        .markdown-content h2 { color: #1e293b; margin-top: 24px; margin-bottom: 12px; border-bottom: 1px solid #f1f5f9; padding-bottom: 4px; font-size: 18pt; }
        .markdown-content h3 { font-size: 14pt; font-weight: 600; margin-top: 16px; margin-bottom: 8px; }
        .markdown-content p { margin-bottom: 12px; line-height: 1.5; }
        .markdown-content ul { list-style-type: disc; padding-left: 20px; margin-bottom: 12px; }
        .markdown-content table { border-collapse: collapse; width: 100%; font-size: 10pt; margin: 16px 0; }
        .markdown-content th { background-color: #f8fafc; font-weight: 600; text-align: left; border: 1px solid #cbd5e1; padding: 10px; }
        .markdown-content td { border: 1px solid #cbd5e1; padding: 10px; vertical-align: top; }
        
        @media print {
          body { background: white !important; }
          .print\\:hidden { display: none !important; }
          .markdown-content { font-size: 11pt; color: black !important; }
          @page { margin: 1.5cm; }
        }
      `}</style>
    </div>
  );
};

export default ProtocolView;
