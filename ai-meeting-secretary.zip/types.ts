
export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  protocol?: string;
  isProtocol?: boolean;
}

export interface MeetingContext {
  transcript: string;
  protocol: string;
}
